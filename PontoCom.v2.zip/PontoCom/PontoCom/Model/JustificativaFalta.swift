//
//  JustificativaFalta.swift
//  PontoCom
//
//  Created by Rubens Parente on 12/08/24.
//
//
//import Foundation
//
//struct JustificativaFalta: Identifiable, Codable {
//    var id: String
//    var dataInicio: Date
//    var dataFinal: Date
//    var localPDF: String
//    var motivo: String
//    var observacao: String
//}
