////
////  JustificativaView.swift
////  PontoCom
////
////  Created by Rubens Parente on 12/08/24.
////
//
//import SwiftUI
//
//struct JustificarFaltasView: View {
//    @StateObject private var viewModel = JustificarViewModel()
//    
//    var body: some View {
//        Form {
//            Section(header: Text("Dados da Falta")) {
//                DatePicker("Data de Início", selection: $viewModel.justificativa.dataInicio, displayedComponents: [.date])
//                DatePicker("Data de Fim", selection: $viewModel.justificativa.dataFinal, displayedComponents: [.date])
//                
//                TextField("Local do PDF", text: $viewModel.justificativa.localPDF)
//                
//                Picker("Motivo", selection: $viewModel.justificativa.motivo) {
//                    Text("Motivo 1").tag("Motivo 1")
//                    Text("Motivo 2").tag("Motivo 2")
//                    Text("Motivo 3").tag("Motivo 3")
//                }
//                
//                TextField("Observação", text: $viewModel.justificativa.observacao)
//            }
//            
//            Button(action: {
//                viewModel.salvarJustificativa()
//            }) {
//                Text("Salvar Justificativa")
//            }
//        }
//        .alert(isPresented: $viewModel.showAlert) {
//            Alert(
//                title: Text("Resultado"),
//                message: Text(viewModel.alertMessage),
//                dismissButton: .default(Text("OK"))
//            )
//        }
//    }
//}
//
//struct JustificarFaltasView_Previews: PreviewProvider {
//    static var previews: some View {
//        JustificarFaltasView()
//    }
//}
