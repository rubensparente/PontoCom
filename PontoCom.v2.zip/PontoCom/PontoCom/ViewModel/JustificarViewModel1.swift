////
////  JustificativaViewModel.swift
////  PontoCom
////
////  Created by Rubens Parente on 12/08/24.
////
//
//import SwiftUI
//import Firebase
//
//class JustificarViewModel: ObservableObject {
//    @Published var justificativa = JustificativaFalta(id: UUID().uuidString, dataInicio: Date(), dataFinal: Date(), localPDF: "", motivo: "", observacao: "")
//    @Published var showAlert = false
//    @Published var alertMessage = ""
//
//    private var db = Firestore.firestore()
//    
//    func salvarJustificativa() {
//        // Validação de dados
//        guard !justificativa.localPDF.isEmpty, !justificativa.motivo.isEmpty else {
//            alertMessage = "Todos os campos obrigatórios devem ser preenchidos."
//            showAlert = true
//            return
//        }
//
//        // Salvar no Firebase
//        db.collection("justificativas").document(justificativa.id).setData([
//            "dataInicio": Timestamp(date: justificativa.dataInicio),
//            "dataFinal": Timestamp(date: justificativa.dataFinal),
//            "localPDF": justificativa.localPDF,
//            "motivo": justificativa.motivo,
//            "observacao": justificativa.observacao
//        ]) { error in
//            if let error = error {
//                self.alertMessage = "Erro ao salvar: \(error.localizedDescription)"
//            } else {
//                self.alertMessage = "Justificativa salva com sucesso!"
//            }
//            self.showAlert = true
//        }
//    }
//}
