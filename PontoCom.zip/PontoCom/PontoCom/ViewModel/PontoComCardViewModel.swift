//
//  PontoComCardViewModel.swift
//  PontoCom
//
//  Created by Rubens Parente on 05/08/24.
//

import SwiftUI

struct PontoComCardViewModel: Identifiable, Equatable {

    var id: Int = 0
    var nome: String = ""
    var cpf: String = ""
    var email: String = ""
    var role: String = ""
    var company: String = ""
    
    
    static func ==(lhs: PontoComCardViewModel, rhs: PontoComCardViewModel) -> Bool{
        
        return lhs.id == rhs.id
    }
}

