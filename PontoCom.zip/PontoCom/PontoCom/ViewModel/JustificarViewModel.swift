//
//  JustificativaViewModel.swift
//  PontoCom
//
//  Created by Rubens Parente on 07/08/24.
//

import Foundation
import Firebase
import FirebaseFirestore
import FirebaseStorage
import UIKit

class JustificarViewModel: ObservableObject {
    @Published var data: Date = Date()
    @Published var horarioInicio: Date = Date()
    @Published var horarioTermino: Date = Date()
    @Published var motivoSelecionado: String?
    @Published var motivos: [String] = ["Doença", "Levar o filho para o Médico", "Outros"]
    @Published var observacao: String = ""
    @Published var pdfData: Data? = nil
    @Published var isSaving: Bool = false
    
    private let db = Firestore.firestore()
    private var storage = Storage.storage().reference()
    
    func salvarJustificar() {
        guard let pdfData = pdfData else {
            print("Nenhum PDF anexado")
            return
        }
        // Salvando o PDF no Firebase Storage
        let pdfRef = storage.child("pdfs/\(UUID().uuidString).pdf")
        pdfRef.putData(pdfData, metadata: nil) { metadata, error in
            if let error = error {
                print("Erro ao fazer upload do PDF: \(error.localizedDescription)")
                return
            }
            
            // Obter a URL do PDF
            pdfRef.downloadURL { [weak self] url, error in
                if let error = error {
                    print("Erro ao obter URL do PDF: \(error.localizedDescription)")
                    return
                }
                
                guard let url = url, let self = self else { return }
                
                guard let user = Auth.auth().currentUser else {
                    print("Usuário não autenticado")
                    return
                }
                
                isSaving = true
                
                let justificar: [String: Any] = [
                    "data": Timestamp(date: data),
                    "horarioInicio": Timestamp(date: horarioInicio),
                    "horarioTermino": Timestamp(date: horarioTermino),
                    "pdfURL": url.absoluteString,
                    "motivo": motivoSelecionado ?? "",
                    "observacao": observacao,
                    "userId": user.uid // Vincular a justificativa ao usuário autenticado
                ]
                
                db.collection("users").document(user.uid).collection("justificativas").addDocument(data: justificar) { error in
                    self.isSaving = false
                    if let error = error {
                        print("Erro ao salvar justificativa: \(error)")
                    } else {
                        print("Justificativa salva com sucesso!")
                    }
                }
            }
        }
    }
    func selecionarPDF(pickerResult: URL?) {
            if let url = pickerResult {
                do {
                    self.pdfData = try Data(contentsOf: url)
                } catch {
                    print("Erro ao ler o PDF: \(error.localizedDescription)")
                }
            }
        }
}
