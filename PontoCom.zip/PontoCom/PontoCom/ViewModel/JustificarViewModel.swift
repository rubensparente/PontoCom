//
//  JustificativaViewModel.swift
//  PontoCom
//
//  Created by Rubens Parente on 07/08/24.
//

import Foundation
import Firebase
import FirebaseFirestore

class JustificarViewModel: ObservableObject {
    @Published var data: Date = Date()
    //@Published var horarioInicio: Date = Date()
    @Published var horarioInicio: Date = Date()
    @Published var horarioTermino: Date = Date()
    @Published var motivoSelecionado: String?
    @Published var motivos: [String] = ["Doença", "Levar o filho para o Médico", "Outros"]
    @Published var observacao: String = ""
    @Published var isSaving: Bool = false
    
    private let db = Firestore.firestore()
    
    func salvarJustificar() {
        guard let user = Auth.auth().currentUser else {
            print("Usuário não autenticado")
            return
        }
        
        isSaving = true
        
        let justificar: [String: Any] = [
            "data": Timestamp(date: data),
            "horarioInicio": Timestamp(date: horarioInicio),
            "horarioTermino": Timestamp(date: horarioTermino),
            "motivo": motivoSelecionado ?? "",
            "observacao": observacao,
            "userId": user.uid // Vincular a justificativa ao usuário autenticado
        ]
        
        db.collection("users").document(user.uid).collection("justificativas").addDocument(data: justificar) { error in
            self.isSaving = false
            if let error = error {
                print("Erro ao salvar justificativa: \(error)")
            } else {
                print("Justificativa salva com sucesso!")
            }
        }
    }
}
