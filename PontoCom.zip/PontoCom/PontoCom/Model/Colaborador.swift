//
//  Colaborador.swift
//  PontoCom
//
//  Created by Rubens Parente on 05/08/24.
//

import Foundation
import FirebaseFirestore

struct Colaborador: Codable{
    var userId: String
    var cpf: String
    var email: String
    var nome: String
    var role: String
    
    init(userId: String, cpf: String, email: String, nome: String, role: String) {
        self.userId = userId
        self.cpf = cpf
        self.email = email
        self.nome = nome
        self.role = role
    }
    
    init?(dictionry: )
}

//    
//    init?(dictionary: [String: Any]) {
//        guard let userId = dictionary["userId"] as? String,
//              let tipo = dictionary["tipo"] as? String,
//              let horario = dictionary["horario"] as? Timestamp,
//              let latitude = dictionary["latitude"] as? Double,
//              let longitude = dictionary["longitude"] as? Double else {
//            return nil
//        }
//        
//        self.userId = userId
//        self.tipo = tipo
//        self.horario = horario.dateValue()
//        self.latitude = latitude
//        self.longitude = longitude
//    }
//    
//    func toDictionary() -> [String: Any] {
//        return [
//            "userId": userId,
//            "tipo": tipo,
//            "horario": Timestamp(date: horario),
//            "latitude": latitude,
//            "longitude": longitude
//        ]
//    }
//}
