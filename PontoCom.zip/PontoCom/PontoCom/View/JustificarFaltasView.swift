//
//  JustificativaFaltasView.swift
//  PontoCom
//
//  Created by Rubens Parente on 07/08/24.
//

import SwiftUI

struct JustificarFaltasView: View {
    @StateObject private var viewModel = JustificarViewModel()
    
    var body: some View {
        NavigationView {
            Form {
                Section{
                    Text("A justificativa de ausência deve ser utilizada caso você tenha se ausentado do trabalho por atestado.")
                        .multilineTextAlignment(.center)
                }
                
                Section(header: Text("Dados da Falta")) {
                    DatePicker("Data", selection: $viewModel.data, displayedComponents: .date)
                    
                    DatePicker("Horário de Início", selection: $viewModel.horarioInicio, displayedComponents: .hourAndMinute)
                    
                    DatePicker("Horário de Término", selection: $viewModel.horarioTermino, displayedComponents: .hourAndMinute)
                    
                    //MultiDatePicker("Horário", selection: $viewModel.horarioInicio)
                            
                }
                
                Section(header: Text("Motivo")) {
                    Picker("Motivo", selection: $viewModel.motivoSelecionado) {
                        ForEach(viewModel.motivos, id: \.self) { motivo in
                            Text(motivo).tag(motivo as String?)
                        }
                    }
                }
                
                Section(header: Text("Observação")) {
                    TextField("Observação", text: $viewModel.observacao)
                }
                
                Section {
                    Button(action: {
                        viewModel.salvarJustificar()
                    }) {
                        if viewModel.isSaving {
                            ProgressView()
                        } else {
                            Text("Salvar")
                        }
                    }
                    .disabled(viewModel.isSaving)
                }
            }
            .navigationTitle("Justificativa de Faltas")
           
        }
    }
}

struct JustificarFaltasView_Previews: PreviewProvider {
    static var previews: some View {
        JustificarFaltasView()
    }
}
