//
//  PerfilView.swift
//  PontoCom
//
//  Created by Daniel Lopes da Silva on 05/08/24.
//

import SwiftUI

struct PerfilView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    PerfilView()
}
