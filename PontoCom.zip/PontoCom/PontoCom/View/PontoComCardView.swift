//
//  PontoComCardView.swift
//  PontoCom
//
//  Created by Rubens Parente on 05/08/24.
//

import SwiftUI

struct PontoComCardView: View {
    
    let viewModel: PontoComCardViewModel
    
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}


struct PontoComCardView_Previews: PreviewProvider{
    static var previews: some View{
        NavigateionView{
            List{
                PontoComCardView(viewModel: <#T##PontoComCardViewModel#>)
            }
        }
    }
}
//#Preview {
//    PontoComCardView()
//}
