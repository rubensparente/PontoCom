//
//  HomeViewModel.swift
//  PontoCom
//
//  Created by Rubens Parente on 30/07/24.
//

import SwiftUI

struct HomeViewModel: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    HomeViewModel()
}
