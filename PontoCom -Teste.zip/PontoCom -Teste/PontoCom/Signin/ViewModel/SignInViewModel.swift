//
//  SignInViewModel.swift
//  PontoCom
//
//  Created by Rubens Parente on 31/07/24.
//

import SwiftUI

class SignInViewModel: ObservableObject{
    
    
    var body: some View{
        Text("Olá Mudno")
    }
}
