//
//  SignInView.swift
//  PontoCom
//
//  Created by Rubens Parente on 31/07/24.
//

import SwiftUI

struct SignInView: View{
    @ObservedObject var viewModel: SignInViewModel
    
    var body: some View{
        Text("Olá")
            .background(Color.blue)
    }
}
