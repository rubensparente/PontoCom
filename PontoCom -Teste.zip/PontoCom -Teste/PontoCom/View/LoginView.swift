//
//  LoginView.swift
//  PontoCom
//
//  Created by Joel Lacerda on 19/07/24.
//

import SwiftUI
import FirebaseAuth
import AVFoundation

struct LoginView: View {
    @State private var email = ""
    @State private var password = ""
    @State private var errorMessage = ""
    
    @ObservedObject var viewModel: SignInViewModel
   
    
    let fu = FirebaseUtils.shared
   
    var body: some View {
        VStack {
            Group {
                Text("PontoC") + Text("o").foregroundStyle(.yellow) + Text("m.")
                    
                  
            }
            .font(.title)
            .accessibilityElement(children: /*@START_MENU_TOKEN@*/.ignore/*@END_MENU_TOKEN@*/)
            .accessibilityLabel(Text("Ponto . com"))
            
            
            TextField("Email", text: $email)
                .textFieldStyle(.roundedBorder)
                .autocorrectionDisabled(true)
                .accessibilityElement(children: /*@START_MENU_TOKEN@*/.ignore/*@END_MENU_TOKEN@*/)
                .accessibilityLabel(Text("Preencha com seu email"))
            
            SecureField("Password", text: $password)
                .textFieldStyle(.roundedBorder)
                .accessibilityElement(children: /*@START_MENU_TOKEN@*/.ignore/*@END_MENU_TOKEN@*/)
                .accessibilityLabel(Text("Coloque sua senha"))
                .padding(.bottom)
               
            
            Button(action: {
                fu.login(email: email, password: password) { result in
                    switch result {
                    case .success(let user):
                        print("Logged in as \(user.email ?? "")")
                    case .failure(let error):
                        errorMessage = error.localizedDescription
                    }
                }
                
            }) {
                Text("Login")
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    
            }
            .accessibilityElement(children: /*@START_MENU_TOKEN@*/.ignore/*@END_MENU_TOKEN@*/)
            .accessibility(label: Text("Aperte o botão para entrar"))
            Text(errorMessage)
                .foregroundColor(.red)
                .accessibilityElement(children: /*@START_MENU_TOKEN@*/.ignore/*@END_MENU_TOKEN@*/)
                .accessibility(label: Text("Mensagem de erro: \(errorMessage.isEmpty ? "Nenhum erro" : errorMessage)"))
                        
        }
        .padding()
        
        
    }
}


//#Preview {
//    LoginView()
//}
