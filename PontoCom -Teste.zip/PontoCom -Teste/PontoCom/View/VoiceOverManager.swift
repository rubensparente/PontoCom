//
//  VoiceOverManager.swift
//  PontoCom
//
//  Created by Rubens Parente on 24/07/24.
//

import Foundation

import AVFoundation

class VoiceOverManager {
    let synthesizer = AVSpeechSynthesizer()

    func speak(text: String) {
        let speechUtterance = AVSpeechUtterance(string: text)
        speechUtterance.voice = AVSpeechSynthesisVoice(language: "pt-BR") // Escolha a voz desejada
        speechUtterance.rate = 0.5 // Defina a velocidade de fala (opcional)
        synthesizer.speak(speechUtterance)
    }
}
