//
//  PontoView.swift
//  PontoCom
//
//  Created by Rubens Parente on 30/07/24.
//

import Foundation
import SwiftUI

//struct PontoComView: View{
//    
//    @ObservedObject var viewModel: PontoComViewModel
//  
//    var body: some View{
//        ZStack{
//            if case PontoComUIState.loading = viewModel.uiState{
//                progress
//            } else if case PontoComUIState.emptyList = viewModel.uiState{
//                
//            }
//        }
//    }
//}
//
//extension PontoComView{
//    var progress: some View{
//        ProgressView()
//    }
//}
//struct PontoComView_Previews: PreviewProvider {
//    static var previews: some View{
//        HomeViewRouter.makePontoView()
//    }
//}
//19:33 IOS Developer

