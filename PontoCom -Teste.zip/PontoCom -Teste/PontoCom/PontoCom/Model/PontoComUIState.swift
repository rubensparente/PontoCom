//
//  PontoComUIState.swift
//  PontoCom
//
//  Created by Rubens Parente on 30/07/24.
//

import Foundation


enum PontoComUIState: Equatable{
    case loading
    case emptyList
    case fullList
    case error(String)
}
