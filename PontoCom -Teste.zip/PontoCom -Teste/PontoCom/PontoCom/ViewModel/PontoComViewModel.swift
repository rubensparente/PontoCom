//
//  PontoComViewModel.swift
//  PontoCom
//
//  Created by Rubens Parente on 30/07/24.
//

import SwiftUI
import Foundation

class PontoComViewModel: Observable{
    @Published var uiState: PontoComUIState = .loading
}
