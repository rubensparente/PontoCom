//
//  HomeViewRouter.swift
//  PontoCom
//
//  Created by Rubens Parente on 30/07/24.
//

import SwiftUI
import Foundation

//enum HomeViewRouter: View {
//    
////    static func makePontoView() -> some View{
//////        let viewModel = PontoComViewModel
//////        return PontoComView(viewModel: viewModel)
////    }
////}
//
//#Preview {
//    HomeViewRouter()
//}
