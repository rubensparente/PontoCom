//
//  SplashRemoteDataSoucer.swift
//  PontoCom
//
//  Created by Rubens Parente on 30/07/24.
//

import SwiftUI

struct SplashRemoteDataSoucer: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    SplashRemoteDataSoucer()
}
