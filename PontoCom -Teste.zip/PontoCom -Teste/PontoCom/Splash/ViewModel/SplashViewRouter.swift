//
//  SplashViewRouter.swift
//  PontoCom
//
//  Created by Rubens Parente on 31/07/24.
//

import SwiftUI

enum SplashViewRouter{
    
    static func makeSignInView() -> some View{
        let viewModel = SignInViewModel()
        //return SignInView(viewModel: viewModel)
        return LoginView(viewModel: viewModel)
    }
}
