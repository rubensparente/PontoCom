//
//  PerfilEditView.swift
//  PontoCom
//
//  Created by Rubens Parente on 19/08/24.
//

import SwiftUI

struct PerfilEditView: View {
    @StateObject private var viewModel = PerfilViewModel()
    @State private var showingAlert = false
    
    
    var body: some View {
        NavigationView {
            if let userProfile = viewModel.userProfile {
                Form {
                    Section(header: Text("Informações do Perfil")) {
//                        TextField("Nome", text: )
//                        TextField("Email", text: )
//                            .keyboardType(.emailAddress)
//                        TextField("CPF", text: )
//                            .keyboardType(.numberPad)
                    }
                    
                    Button(action: {
                        viewModel.updateProfile(name: userProfile.name, email: userProfile.email, cpf: userProfile.cpf)
                        showingAlert = true
                    }) {
                        Text("Atualizar")
                    }
                    
                    if let errorMessage = viewModel.errorMessage {
                        Text(errorMessage)
                            .foregroundColor(.red)
                    }
                }
            }
//            .navigationTitle("Atualizar Perfil")
//            .alert(isPresented: $showingAlert) {
//                Alert(title: Text("Perfil Atualizado"), message: Text("Seu perfil foi atualizado com sucesso."), dismissButton: .default(Text("OK")))
            }
        }
    }
//}
struct PerfilEditView_Previews: PreviewProvider {
    static var previews: some View {
        PerfilEditView()
    }
}
