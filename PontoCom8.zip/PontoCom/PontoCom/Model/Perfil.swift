//
//  Perfil.swift
//  PontoCom
//
//  Created by Rubens Parente on 20/08/24.
//

import Foundation

struct Perfil {
    var name: String
    var email: String
    var cpf: String
}
