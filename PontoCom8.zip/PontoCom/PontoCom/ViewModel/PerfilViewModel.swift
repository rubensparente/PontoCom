//
//  PerfilViewModel.swift
//  PontoCom
//
//  Created by Rubens Parente on 19/08/24.
//

import Foundation
import FirebaseAuth
import FirebaseFirestore

class PerfilViewModel: ObservableObject {
    @Published var userProfile: Perfil?
    @Published var errorMessage: String?
    
    private let db = Firestore.firestore()
    
    init() {
        fetchUserProfile()
    }
    
    func fetchUserProfile() {
        guard let userId = Auth.auth().currentUser?.uid else {
            errorMessage = "Usuário não autenticado."
            return
        }
        
        db.collection("users").document(userId).getDocument { [weak self] document, error in
            if let document = document, document.exists {
                let data = document.data()
                self?.userProfile = Perfil(
                    name: data?["name"] as? String ?? "",
                    email: data?["email"] as? String ?? "",
                    cpf: data?["cpf"] as? String ?? ""
                )
            } else {
                self?.errorMessage = "Erro ao carregar dados."
            }
        }
    }
    
    func updateProfile(name: String, email: String, cpf: String) {
        guard let userId = Auth.auth().currentUser?.uid else {
            errorMessage = "Usuário não autenticado."
            return
        }
        
        db.collection("users").document(userId).setData([
            "name": name,
            "email": email,
            "cpf": cpf
        ]) { [weak self] error in
            if let error = error {
                self?.errorMessage = "Erro ao atualizar perfil: \(error.localizedDescription)"
            } else {
                self?.fetchUserProfile()
            }
        }
    }
}

