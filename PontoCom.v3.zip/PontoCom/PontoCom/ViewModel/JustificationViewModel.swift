//
//  JustificationViewModel.swift
//  PontoCom
//
//  Created by Rubens Parente on 12/08/24.
//

import SwiftUI
import Firebase
import FirebaseFirestore
import FirebaseStorage

class JustificationViewModel: ObservableObject {
    @Published var startDate = Date()
    @Published var endDate = Date()
    @Published var reason = ""
    @Published var notes = ""
    @Published var fileURL: URL?
    @Published var showingAlert = false
    @Published var alertMessage = ""
    @Published var alertType: AlertType = .success
    
    enum AlertType {
        case success
        case failure
    }
    
    private var db = Firestore.firestore()
    private var storage = Storage.storage()
    
    func submitJustification() {
        guard !reason.isEmpty else {
            alertMessage = "O motivo é obrigatório."
            alertType = .failure
            showingAlert = true
            return
        }
        
        
        guard let user = Auth.auth().currentUser else {
            print("Usuário não autenticado")
            return
        }
        
        let id = UUID().uuidString
        let justification = Justification(
            id: id,
            startDate: startDate,
            endDate: endDate,
            reason: reason,
            notes: notes,
            fileURL: fileURL
        )
        
        // Save justification to Firestore
        db.collection("users").document(user.uid).collection("justifications").document(id).setData([
            "startDate": justification.startDate,
            "endDate": justification.endDate,
            "reason": justification.reason,
            "notes": justification.notes,
            "fileURL": justification.fileURL?.absoluteString ?? ""
        ]) { error in
            if let error = error {
                self.alertMessage = "Erro ao salvar justificativa: \(error.localizedDescription)"
                self.alertType = .failure
            } else {
                self.alertMessage = "Justificativa salva com sucesso!"
                self.alertType = .success
            }
            self.showingAlert = true
        }
        
        // Upload file to Firebase Storage if available
        if let fileURL = fileURL {
            let fileName = fileURL.lastPathComponent
            let storageRef = storage.reference().child("justifications/\(fileName)")
            
            storageRef.putFile(from: fileURL, metadata: nil) { metadata, error in
                if let error = error {
                    print("Erro ao fazer upload do arquivo: \(error.localizedDescription)")
                } else {
                    print("Arquivo carregado com sucesso!")
                }
            }
        }
    }
}

