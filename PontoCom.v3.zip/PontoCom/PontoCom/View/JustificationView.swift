//
//  JustificationView.swift
//  PontoCom
//
//  Created by Rubens Parente on 12/08/24.
//

import SwiftUI

struct JustificationView: View {
    @StateObject private var viewModel = JustificationViewModel()
    @State private var showFilePicker = false
    @State private var reasons = ["Doença", "Acidente", "Consulta Médica", "Outro"]
    @State private var selectedReason = "Doença"
    
    var body: some View {
        NavigationView {
            Form {
                Section{
                    Text("A justificativa de ausência deve ser utilizada caso você tenha se ausentado do trabalho por atestado.")
                        .multilineTextAlignment(.center)
                }
                Section(header: Text("Datas")) {
                    DatePicker("Data Inicial", selection: $viewModel.startDate, displayedComponents: [.date, .hourAndMinute])
                    DatePicker("Data Final", selection: $viewModel.endDate, displayedComponents: [.date, .hourAndMinute])
                }
                
                Section(header: Text("Motivo")) {
                    Picker("Motivo", selection: $selectedReason) {
                        ForEach(reasons, id: \.self) { reason in
                            Text(reason).tag(reason)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                }
                
                Section(header: Text("Observação")) {
                    TextField("Observação", text: $viewModel.notes)
                }
                
                Section(header: Text("Anexar Atestado Médico")) {
                    HStack{
                        Button(action: {
                            showFilePicker = true
                        }) {
                            Text("Selecionar Arquivo")
                                .multilineTextAlignment(.leading)
                        }
                        Spacer()
                        
                        Image(systemName: "tray.and.arrow.down")
                            .multilineTextAlignment(.trailing)
                    }
                }
                Button(action: {
                    viewModel.reason = selectedReason
                    viewModel.submitJustification()
                }) {
                    Text("Salvar")
                        .padding()
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }.frame(maxWidth: .infinity)
            }
            .navigationTitle("Justificar Falta")
            .fileImporter(isPresented: $showFilePicker, allowedContentTypes: [.pdf]) { result in
                switch result {
                case .success(let url):
                    viewModel.fileURL = url
                case .failure(let error):
                    print("Erro ao selecionar arquivo: \(error.localizedDescription)")
                }
            }
            .alert(isPresented: $viewModel.showingAlert) {
                Alert(
                    title: Text(viewModel.alertType == .success ? "Sucesso" : "Erro"),
                    message: Text(viewModel.alertMessage),
                    dismissButton: .default(Text("OK"))
                )
            }
        }
    }
}

struct JustificationView_Previews: PreviewProvider {
    static var previews: some View {
        JustificationView()
    }
}
