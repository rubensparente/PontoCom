//
//  JustificativaFaltasView.swift
//  PontoCom
//
//  Created by Rubens Parente on 07/08/24.
//

import SwiftUI
import UniformTypeIdentifiers
import UIKit

struct JustificarFaltasView: View {
    @StateObject private var viewModel = JustificarViewModel()
    @State private var showingDocumentPicker = false
   
    @StateObject private var alertMessage = JustificarViewModel()
    
    
    var body: some View {
        NavigationView {
           Form {
                Section{
                    Text("A justificativa de ausência deve ser utilizada caso você tenha se ausentado do trabalho por atestado.")
                        .multilineTextAlignment(.center)
                }
                
                Section(header: Text("Período")) {
                    DatePicker("Início", selection: $viewModel.horarioInicio, displayedComponents: [.date, .hourAndMinute])
                    DatePicker("Término", selection: $viewModel.horarioTermino, displayedComponents: [.date, .hourAndMinute])
                }
                
                Section(header: Text("Anexo")) {
                    
                    HStack{
                        Button(action: {
                            showingDocumentPicker = true
                        }) {
                            Text(viewModel.pdfData == nil ? "Anexar Documento" : "Documento Selecionado")
                                
                                .multilineTextAlignment(.leading)
                            
                            
                            
                        }
                        .fileImporter(isPresented: $showingDocumentPicker, allowedContentTypes: [.pdf]) { result in
                            do {
                                let fileURL = try result.get()
                                viewModel.selecionarPDF(pickerResult: fileURL)
                            } catch {
                                print("Erro ao selecionar o PDF: \(error.localizedDescription)")
                            }
                                
                        }
                        Spacer()
                        Image(systemName: "tray.and.arrow.down")
                          
                            .multilineTextAlignment(.trailing)
                    }
                    
                }
                Section(header: Text("Motivo")) {
                    Picker("Motivo", selection: $viewModel.motivoSelecionado) {
                        ForEach(viewModel.motivos, id: \.self) { motivo in
                            Text(motivo).tag(motivo as String?)
                        }
                    }
                }
                
                Section(header: Text("Observação")) {
                    TextEditor( text: $viewModel.observacao)
                }
               
               Section {
                   HStack {
                       Button(action: {
                           viewModel.salvarJustificar()
                        
                       }) {
                           if viewModel.isSaving {
                               ProgressView()
                           } else {
                               Text("Salvar")
                                   //.font(.headline)
                                   .padding()
                                   .background(Color.verde)
                                   .foregroundColor(.white)
                                   .cornerRadius(10)
                           }
                           
                       }
                       .disabled(viewModel.isSaving)
                       .frame(maxWidth: .infinity)
                       
                   }

               }
            }
            .navigationTitle("Justificar Faltas")
        }
    }
    
}
struct JustificarFaltasView_Previews: PreviewProvider {
    static var previews: some View {
        JustificarFaltasView()
    }
}
